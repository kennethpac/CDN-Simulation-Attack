﻿Public Class Form1

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Timer1.Enabled = True

    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        If pg.Value <= pg.Maximum - 1 Then
            pg.Value += 1
            If pg.Value = 20 Then
                cdna.Text = msg1
            ElseIf pg.Value = 40 Then
                cdna.Text = "Request recieved and being processed ........"
            ElseIf pg.Value = 60 Then
                cdna.Text = "Request contains Forward address to a CDN B Destination Server  ........"
            ElseIf pg.Value = 80 Then
                cdna.Text = "HOST field is been modified to the destination server  ........"
            ElseIf pg.Value = 90 Then
                cdna.Text = "Request sent to the Destination Address server with a RETURN address saved"
            ElseIf pg.Value = 100 Then

               

                pg.Value = 0
                pg.Refresh()
                ' pg.Value = pg.Maximum

                Timer1.Enabled = False
                Timer2.Enabled = True
            End If
        Else
        End If
        If msg = 1 Then
            PictureBox4.Visible = True
            msg1 = "Receiving returning address by saved CDN HOST"
        
        End If
    End Sub
    Dim msg = 0
    Dim msg1 = ""
    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        'MsgBox("hello")

        

        If pg.Value <= pg.Maximum - 1 Then
            pg.Value += 1
            If pg.Value = 20 Then
                cdnb.Text = msg1
            ElseIf pg.Value = 40 Then
                cdnb.Text = "Request recieved and being processed ........"
            ElseIf pg.Value = 60 Then
                cdnb.Text = "Request contains Forward address to a CDN C Destination Server  ........"
            ElseIf pg.Value = 80 Then
                cdnb.Text = "HOST field is been modified to the destination server  ........"
            ElseIf pg.Value = 90 Then
                cdnb.Text = "Request sent to the Destination Address server with a RETURN address saved"
            ElseIf pg.Value = 100 Then
                pg.Value = 0
                pg.Refresh()
                ' pg.Value = pg.Maximum

                Timer2.Enabled = False
                Timer3.Enabled = True

            End If
        Else
        End If
    End Sub

    Private Sub Timer3_Tick(sender As Object, e As EventArgs) Handles Timer3.Tick
        If pg.Value <= pg.Maximum - 1 Then
            pg.Value += 1
            If pg.Value = 20 Then
                cdnc.Text = msg1
            ElseIf pg.Value = 40 Then
                cdnc.Text = "Request recieved and being processed ........"
            ElseIf pg.Value = 60 Then
                cdnc.Text = "Request contains Forward address to a CDN A Destination Server  ........"
            ElseIf pg.Value = 80 Then
                cdnc.Text = "HOST field is been modified to the destination server  ........"
            ElseIf pg.Value = 90 Then
                cdnc.Text = "Request sent to the Destination Address server with a RETURN address saved"
            ElseIf pg.Value = 100 Then
                pg.Value = 0
                pg.Refresh()
                ' pg.Value = pg.Maximum

                Timer3.Enabled = False
                Timer1.Enabled = True
                msg = 1

            End If
        Else
        End If
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
